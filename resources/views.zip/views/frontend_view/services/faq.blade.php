@extends('frontend_view.layouts.layout')
    @section('content')

<style>
.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

/*.card{
    background-color: #aaa;
    color: #fff;
    padding: 15px 30px;
    border-radius: 3px;
    cursor: pointer;
    margin-bottom: 10px;
}
.card-title{
    font-size: 22px;
    margin: 0px;
}
.card-body{
    display:none;
    cursor: default;
}*/
.accordion-collapse {
 transition: max-height 0.5s ease-out;
 overflow: hidden;
}
</style>


    <section class="site-section zero_padding">
        <div class="row">
            <div class="col-md-12 text-center">
                <img src="{{ URL('assets/images/support/faq.png') }}" alt="Snow" style="width:100%; height:550px;"/>
                <h1 class="centered heading">How we can <span class="text-white">help </span></h1>
            </div>
        </div>
    </section>

    <section class="site-section lighter-bg" id="meet">
        <div class="container">
            <div class="row justify-content-center">
                        
                <div class="col-md-12 text-center general-text-color">
                    <h2 class="heading themeTextColor">Frequently Asked Questions</h2>
                    <p>Welcome to our FAQ, Here you can find answers <br/>to some of the most asked questions.</p>
                </div>

                <div class="col-md-12 padding-top-bot-40">
 
                
                    <div class="main-div" style="display:flex; flex-direction: row; flex-wrap: wrap; justify-content:space-around;">
                        @if($faq_data->isNotEmpty())
                            @foreach($faq_data as $val)
                            <div class="col-md-6" style="padding:0 20px;">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button type="button" data-bs-toggle="collapse" aria-expanded="true" aria-controls="collapseOne" class="accordion-button themebackgroundColor" data-bs-target="#collapse{{$loop->index}}">
                                            {{ $val->question }} <span class="arrow"></span>
                                        </button>
                                    </h2>
                                    <div id="collapse{{$loop->index}}" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <text>{!! $val->answer !!}</text>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                        @endif


                        <!-- <div class="col-md-6" >

                            <div class="card" index='0'>
                                <p>Hello world #1</p>
                                <div class="card-body">
                                    <p>1st Para</p>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-6" >
                            <div class="card" index='1'>
                                <p>Hello world #2</p>
                                <div class="card-body">
                                    <p>2 Para</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" >
                            <div class="card" index='2'>
                                <p>Hello world #3</p>
                                <div class="card-body">
                                    <p>3 Para</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" >
                            <div class="card" index='3'>
                                <p>Hello world #4</p>
                                <div class="card-body">
                                    <p>4 Para</p>
                                </div>
                            </div>
                        </div> -->


                        

                        
                    </div>

                </div>
            </div>
        </div>
    </section>

    @endsection