@extends('frontend_view.layouts.layout')
    @section('content')

    <section class="site-section-hero bg-image" style="background-image: url(&quot;../../../assets/images/img_9.jpg&quot;); height: 60vh; background-position: 50% 1%; min-height: 150px;" data-stellar-background-ratio="0.5" id="home-border"> 
        <div class="container">
            <div class="row justify-content-center  align-items-center" style="height: 60vh;">
                <div class="col-md-12 ">

                    <div class="row justify-content-center  align-items-center" style="height: 50vh;">
                        <div class="col-md-12">
                            <div data-aos="fade-up" data-aos-delay="100" class="aos-init text-white aos-animate">
                                <h1 class="text-white heading">Browse our catalogues  </h1>
                                <h1 class="text-white heading">for our full product range </h1>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>


    <section class="site-section gradient-left-to-right text-center">
        <div class="container">
            <div class="row justify-content-center">
                
                <div class="col-md-12">
                    <div data-aos="fade-up" data-aos-delay="100" class="aos-init aos-animate">
                        <h1 class="heading">Catalogues </h1>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam.</p>
                        
                    </div>
                </div>

                <div class="col-md-6 col-sm-6">
                    <div class="teaser hover_icon text-center">
                        <div> <img class="catalouge_image rounded-circle" src="https://www.johnsontestpapers.com/images/rapidtests.jpg"> </div>
                            <h3 class="topmargin_20 hover-color2 text-white"><a href="https://www.johnsontestpapers.com/catalogue?name=rapid" class="text-white" target='_blank'> Rapid Test </a></h3>
                        </div>
                    </div>
                <div class="col-md-6 col-sm-6">
                    <div class="teaser hover_icon text-center">
                        <div> <img class="catalouge_image rounded-circle" src="{{ URL('assets/images/catalogue_filtration_paper_image.png') }}"> </div>
                            <h3 class="topmargin_20 hover-color2"><a href="https://www.johnsontestpapers.com/catalogue?name=filtration" class="text-white" target='_blank'> Filtration </a></h3>
                    </div>
                </div>

            </div>
        </div>
        </section>

    @include('frontend_view.layouts.contact_section')
    @endsection