@extends('frontend_view.layouts.layout')
    @section('content')

    <section class="site-section-hero bg-image" style="background-image: url(&quot;../../../assets/images/img_9.jpg&quot;); height: 60vh; background-position: 50% 1%; min-height: 150px;" data-stellar-background-ratio="0.5" id="home-border"> 
        <div class="container">
            <div class="row justify-content-center  align-items-center" style="height: 60vh;">
                <div class="col-md-12 ">

                    <div class="row justify-content-center  align-items-center" style="height: 50vh;">
                        <div class="col-md-12">
                            <div data-aos="fade-up" data-aos-delay="100" class="aos-init text-white aos-animate">
                                <h1 class="text-white heading">Education  </h1>
                                <p> Testing </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>


    <section class="site-section lighter-bg" id="section-nav">
        <div class="container">

            <div class="row justify-content-center">
            
                <div class="col-md-12 text-center">
                    <h1 class="themeTextColor">We offers a range of science education tests for water, soil and air sampling.</h3>
                    <br/><br/>
                    <p>Ideal for projects and field experiments, our products are designed for use with both the primary and secondary school science and education curriculums. One of our most popular lines is the pH 1 - 14 books, designed as a cost effective solution for the classroom and to promote awareness of acid/base chemistry. Johnson Test Papers has also worked in conjunction with the BBC to develop test kits containing our water hardness and glucose tests for the Science Workshop Programme.</p>
                </div>

                <div class="col-md-12">
                        <div class="card">
                              <div class="card-header">
                                <ul class="nav nav-tabs navmenu">
                                    @if ($cat_data->isNotEmpty())
                                        @foreach ($cat_data as $index => $item)
                                            <li class="col-md-12 text-center text-uppercase nav-item navbar-filter-papers" data-myAttri="tab-{{$index}}">
                                                <a  href="#tab-{{$index}}" class="nav-link">{{ $item->cat_name }}</a>
                                            </li>
                                            <?php 
// print_r($item->id);
// $sub_cat_ranges = DB::table('sub_cat_ranges as scr')
//                     ->join('subcategory as sc', 'sc.id', '=','scr.subcategory_id')
//                     ->where('scr.sub_cat_tags', 'like', '%'.$item->id.'%')
//                     ->get();
?>
                                        <?php /* @if($sub_caty_ranges->isNotEmpty())
                                            @foreach ($sub_caty_ranges as $val)
                                                <div class="card-body" id='tab-{{$index}}'> {{$val->sub_cat_name}} {{$val->sub_cat_ranges}} </div>
                                            @endforeach
                                        @endif */ ?>
                                            <div class="card-body" id='tab-{{$index}}'> {{$item->sub_cat_name}} {{$item->sc_ranges}} </div>
                                            @endforeach
                                    @endif 
                                    
                                  <!-- <div class="card-body" id='tab-1-active'> 1 </div> -->
                                  <li class="col-md-12 text-center text-uppercase nav-item navbar-filter-papers" data-myAttri="tab-2">
                                    <a href="#tab-2" class="nav-link">Applications</a>
                                  </li>
                                  <div class="card-body" id='tab-2-active' style="display:none;"> 2 </div>

                                  <!--<li class="col-md-12 text-center text-uppercase nav-item navbar-filter-papers" data-myAttri="tab-3">
                                    <a href="#tab-3" class="nav-link">Industries</a>
                                  </li>
                                  <div class="card-body" id='tab-3-active' style="display:none;"> 3 </div> -->
                                </ul>
                              </div>

                              

                              

                              

                        </div>
                    </div>

            </div>

        </div>
    </section>

    @include('frontend_view.layouts.contact_section')
    @endsection