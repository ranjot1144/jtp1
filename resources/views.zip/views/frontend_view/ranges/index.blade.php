@extends('frontend_view.layouts.layout')
  @section('content')
<style>
  .owl-stage .owl-item{
      .item {
        p{
          margin:0px;
          color: #000;
        }
        img {
          height:200px; 
          padding:20px 15px;
          border-radius: 25%;
      }
      img:hover{
        border-radius:50%;
        opacity:0.5;
      }
    }
  }

</style>
    <div class="container-fluid">
      @include('frontend_view.layouts.breadcrumb_nav')
                
        <!-- <section class="intro_section" id="banner_slider">

          <div id="carousel-thumb" class="carousel carousel-thumbnails slide" data-ride="carousel" data-interval="15000">
        
              <div class="carousel-inner" role="listbox" style="height: 710px; width: 100%; overflow: hidden;">
                  <div class="carousel-item active">
                    <img class="carousel-img-fit" src="{{URL('assets/images/slider_1.png')}}" alt="First slide" style="max-height:730px !important;">
                    <div class="row carousel-ban-text-adj">
                      <div class="row col-12">
                        <h1 class="col-12 carousel-header-adj heading"><?php 
                          if(!empty($range_pro_data) && isset($range_pro_data)) {
                            echo $range_pro_data[0]->range_name;
                          } ?>
                        </h1>
                        <h1 class="col-12 carousel-header-adj heading themeTextColor">Quick Accurate & Easy </h1>
                        <h1 class="col-12 carousel-header-adj heading">Industry leading results</h1>
                        <h1 class="text-white heading aos-init aos-animate" data-aos="fade-right">Your Specialist</h1>
                      </div>
                    </div>
                  </div>
                
                  <div class="carousel-item ">
                    <img class="carousel-img-fit" src="{{URL('assets/images/slider_2.png')}}" alt="Second slide" style="max-height:730px !important;">
                          <div class="row carousel-ban-text-adj">
                      <div class="row col-12">
                        <h1 class="col-12 carousel-header-adj">Lorem Ipsum</h1>
                        <p class="col-12 carousel-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elite. </p>
                        <a href="/internet" class="btn btn-primary btn-large col-md-3">Neque porro</a>
                      </div>
                    </div>
                  </div>

                  <div class="carousel-item">
                    <img class="carousel-img-fit" src="{{URL('assets/images/slider_3.png')}}" alt="Third slide" style="max-height:730px !important;">
                    <div class="row carousel-ban-text-adj">
                      <div class="row col-12">
                        <h1 class="col-12 carousel-header-adj">Lorem Ipsum</h1>
                        <p class="col-12 carousel-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                        <a href="/#" class="btn btn-primary btn-large col-md-3">Neque porro</a>
                      </div>
                    </div>
                  </div>
              </div>

              <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>

              <ol class="carousel-indicators">
                <li data-target="#carousel-thumb" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-thumb" data-slide-to="1"></li>
                <li data-target="#carousel-thumb" data-slide-to="2"></li>
              </ol>

          </div>

        </section> -->






<section class="intro_section" id="slider">

<div id="carousel-thumb" class="carousel carousel-thumbnails slide" data-ride="carousel" data-interval="15000">
      <div class="carousel-inner" role="listbox">
            <!-- <div class="carousel-item active carousel-banner"> -->
            <div class="carousel-item active">
              <img class="d-block w-100 carousel-img-fit" src="http://127.0.0.1:8000/assets/images/slider_1.png" alt="First slide" style="min-height:600px;">
                    <div class="row carousel-ban-text-adj">
                <div class="row col-12">
                  <h1 class="col-12 carousel-header-adj">Lorem Ipsum</h1>
                  <p class="col-12 carousel-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elito. </p>
                  <a href="/internet" class="btn btn-primary btn-large col-md-3">Neque porro</a>
                </div>
              </div>
            </div>
            <div class="carousel-item ">
              <img class="d-block w-100 carousel-img-fit" src="http://127.0.0.1:8000/assets/images/slider_2.png" alt="Second slide" style="min-height:600px;">
                    <div class="row carousel-ban-text-adj">
                <div class="row col-12">
                  <h1 class="col-12 carousel-header-adj">Lorem Ipsum</h1>
                  <p class="col-12 carousel-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elite. </p>
                  <a href="/internet" class="btn btn-primary btn-large col-md-3">Neque porro</a>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100 carousel-img-fit" src="http://127.0.0.1:8000/assets/images/slider_3.png" alt="Third slide"  style="min-height:600px;">
              <div class="row carousel-ban-text-adj">
                <div class="row col-12">
                  <h1 class="col-12 carousel-header-adj">Lorem Ipsum</h1>
                  <p class="col-12 carousel-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                  <a href="/#" class="btn btn-primary btn-large col-md-3">Neque porro</a>
                </div>
              </div>
            </div>
      </div>
      <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
      <ol class="carousel-indicators">
        <li data-target="#carousel-thumb" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-thumb" data-slide-to="1"></li>
        <li data-target="#carousel-thumb" data-slide-to="2"></li>
      </ol>
</div>
</section>



        <section class="site-section lighter-bg" id="content_section">
          <div class="container">
            <div class="row justify-content-center general-text-color">

                <div class="col-md-12 text-center general-text-color">
                  <h2 class="heading">Our Range</h2>
                  @if($range_data->isNotEmpty())
                    <p>{!! $range_data[0]->range_desc !!}</p>
                  @endif
                </div>
              
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header">

                        <div class="row text-center">
                            <?php
                            $col_val=  '';
                              if(!empty($range_pro_data) && isset($range_pro_data) ) {
                                $col_val = count($range_pro_data);
                                if($col_val==1) {
                                  $col_val = '12';
                                }else if($col_val==2) {
                                  $col_val = '6';
                                } else if($col_val>=3) { 
                                  $col_val = '4';
                                }

                                foreach($range_pro_data as $range) {
                                    if(!empty($range->prod_name)) {
                                      $url_ranges_page = strtolower(str_replace(' ', '_', $range->range_name));
                                    ?>
                                      <div class="col-md-{{$col_val}} ranges_prod">
                                        <a href="{{ url('/product/'.$url_ranges_page.'/'.$range->prod_url) }}">
                                          <img src="https://www.johnsontestpapers.com/images/products/filter-boxes.jpg" alt="Snow" class="img-fluid tab_hover">
                                          <label class="margin-top-10 font-weight-500 general-text-color">{!! $range->prod_name !!}</label>
                                          <br/>
                                          <label class="margin-top-10 font-weight-500 general-text-color">This is test</label>
                                        </a>
                                      </div>
                                  <?php }
                                }
                              }
                            ?>
                        </div><!-- row -->
                    </div> <!-- card header -->
                  </div> <!--card -->
                </div> <!-- col-md-12 -->

            </div><!-- Row -->
          </div><!-- Container -->
        </section>


        <?php if($range_data[0]->prod_id=='3' || $range_data[0]->prod_id=='5') { ?>
          <section class="site-section-hero bg-image" style="height: 30vh; min-height: 250px; background:var(--blue);" data-stellar-background-ratio="0.5" id="test-strip-filteration"> 
            <div class="container">
                <div class="row justify-content-center  align-items-center" style="min-height: 250px; height: 30vh;">
                    
                    <div class="col-md-12 ">
                    

                        <div class="row justify-content-center  align-items-center" style="min-height: 250px; height: 30vh;">
                            <div class="col-md-8">
                                <div data-aos="fade-up" data-aos-delay="100" class="aos-init text-white aos-animate">
                                    <h1>Explore the Pool &amp; Spa Range</h1>
                                    <h3>For All Your Testing Needs at <a href="https://draft.check2o.com/">draft.check2o.com/ </a></h3>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <img src="https://draft.check2o.com/wp-content/uploads/elementor/thumbs/Check2O_logo_small-qd9vmyzff0ftbzfher11m9c3ert3dhib9ktottpt6c.png">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
          </section>
        <?php } else { ?>
        <section class="site-section-hero bg-image" style="background-image: url('../assets/images/img_9.jpg'); height:60vh;" data-stellar-background-ratio="0.5" id="industry-section-carousel">
          
          <div class="row justify-content-center align-items-center" style="height:30vh;">
              <div class="col-md-7 text-white text-center">
                    <h1 class="heading bold-text" data-aos="fade-right"> Products By Industry Sectors</h1>
                      <p class='button-margin-15' data-aos="fade-up" data-aos-delay="300">
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor<br/>invidunt ut labore et dolore magna aliquyam erat, sed diam.
                      </p>
              </div><!-- col-md-7 -->

              <div class="col-md-12">
                <div class="owl-carousel slide-one-item home-slider">
                    <div class="item"> 
                      <a href="{{ URL('product/industries') }}">
                        <img src="{{ asset('../assets/images/person_1.jpg') }}" alt="Image" class="mx-auto img-fluid w-50"> <p class="text-center">View All</p>
                      </a>
                    </div>

                  <?php if(!empty($industry_data)){
                    foreach($industry_data as $data){
                      if($data->range_id=='6'){ 
                              $redirect_url = URL('product/industry/'.$data->prod_url);
                              $img_url = URL('../assets/images/'.$data->prod_images); 

                      ?>
                    <div class="item">
                      <a href="<?php echo $redirect_url; ?>">
                        <img src="<?php echo $img_url; ?>" alt="Image" class="mx-auto img-fluid w-50" > <p class="text-center">{{ $data->prod_name }}</p>
                      </a>
                    </div>
                      <?php }

                      }
                  } ?>
                </div>
              </div><!-- col-md-12 -->

            </div><!-- Row -->
        </section>
        <?php } ?>

      @include('frontend_view.layouts.contact_section')
                
    </div>
        <!-- </main> -->
  @endsection