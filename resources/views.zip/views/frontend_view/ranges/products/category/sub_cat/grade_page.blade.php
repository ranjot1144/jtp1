@extends('frontend_view.layouts.layout')
    @section('content')
        
    <!-- <main class="main-content">
       <div class="container-fluid"> -->
                
       @include('frontend_view.layouts.breadcrumb_nav')

               <section class="site-section-hero bg-image bg-header-image" data-stellar-background-ratio="0.5" id="section-home">
                  <div class="row justify-content-center align-items-center">
                      <div class="col-md-10">
                            <h1 class="heading filterpapercolor bold-text" data-aos="fade-right"> <?php echo $sub_cat_data[0]->sub_cat_name; ?></h1>
                      </div>
                  </div>
                </section>

              <?php $colorclass='';
              if(!empty($range_data) && $range_data[0]->range_id=='1'){
                $colorclass = 'rapid_text_color';
              }else{
                $colorclass = 'filtration_text_color';
              }
              ?>

                <section class="site-section lighter-bg">
                    <div class="container">
                      <div class="row justify-content-center">
                        
                        <div class="col-md-10">
                          <h2 class="heading text-center">Grades</h2>
                          <p>Our Ashless Filter Papers are made under the strictest conditions using high quality raw materials. The ashless filter paper grades are made
                          with 100% cotton linter fibres. Cellulose fibres in their natural state contain small quantities of organic and inorganic impurities. <a href="">Read More</a></p>
                        </div>

                        <div class="col-md-12 table-responsive text-center padding-top-bot-40">
                            <table class="table-striped">
                              <thead>
                                <tr class="gradient-left-to-right">
                                  <th scope="col">Grade</th>
                                  <th scope="col">Whatman <br/> Equivalent</th>
                                  <th scope="col">Filtering <br/> Speed</th>
                                  <th scope="col">Thickness <br/> (mm)</th>
                                  <th scope="col">Pore Size <br/> (M)</th>
                                  <th scope="col">Weight <br/> (g/m2)</th>
                                  <th scope="col">Filteration Speed <br/> (sec*)</th>
                                  <th scope="col">Burst Strength <br/> (kg/cm2)</th>
                                </tr>
                              </thead>
                              <tbody>

                                <?php if(!empty($grade_data)) {
                                        foreach($grade_data as $data) {
                                        
                                          $grade_desc = '';
                                          if(isset($data->grade_desc) && !empty($data->grade_desc)){
                                            $grade_desc = $data->grade_desc;
                                          }

                                          $cnt = 0;
                                          if(isset($grade_code) && !empty($grade_code)) {
                                              $cnt = count($grade_code);
                                          }
                                          echo '<tr class="parent" id="row'.$data->id.'" title="Click to expand/collapse" style="cursor: pointer;">
                                                  <td>'.$data->grade_range.' <span style="float:right;">+</span></td>
                                                  <td>= No.'.$data->whatman_equivalent.'</td>
                                                  <td>'.$data->filtering_speed.'</td>
                                                  <td>'.$data->thickness.'</td>
                                                  <td>'.$data->pore_size.'</td>
                                                  <td>'.$data->weight.'</td>
                                                  <td>'.$data->filtration_speed.'</td>
                                                  <td>'.$data->burst_strength.'</td>
                                                </tr>';

                                            if(isset($grade_desc) && !empty($grade_desc)) {
                                              echo '<tr class="child-row'.$data->id.'" style="display:none;">
                                                  <th> </td>  
                                                  <th colspan="4">Grade 351 <span style="padding:15px; background: #A0BF1A; color:#fff;">Very Slow filtering</span></td>  
                                                  <th> </td>  
                                                  <th> Sizes <br/>(Diameter/mm) </td> 
                                                  <th> Product Code</td>  
                                                </tr>

                                                <tr class="child-row'.$data->id.'" style="display:none;">
                                                  <td> </td>  
                                                  <td colspan="4" rowspan='.$cnt.' style="text-align:left; vertical-align: top; width:50%;">'.$grade_desc.'
                                                  <td> &nbsp;</td>  
                                                  <td> </td>
                                                  <td> </td>
                                                </tr>';
                                                
                                                  if($data->id==$grade_code[0]->grade_desc_id) {
                                                    foreach($grade_code as $index => $gc) { 
                                                      echo '<tr class="child-row'.$data->id.'" style="display:none;">
                                                            <td> </td>
                                                            <td> </td>
                                                            <td>'.$gc->gc_size.'</td>
                                                            <td>'.$gc->gc_prod_code.'</td>
                                                            </tr>';   
                                                    } 
                                                  }
                                              }
                                            
                                        }
                                      }?>
                                
                              </tbody>
                            </table>
                        </div>



                      </div>
                    </div>
                </section>

                <!-- <section class="site-section lighter-bg">
                    <div class="container">
                      <div class="row justify-content-center">
                        
                        <div class="col-md-12 table-responsive text-center">
                            <table class="table-striped">
                              <thead>
                                <tr class="gradient-left-to-right">
                                  <th scope="col">Grade</th>
                                  <th scope="col">Whatman <br/> Equivalent</th>
                                  <th scope="col">Filtering <br/> Speed</th>
                                  <th scope="col">Thickness <br/> (mm)</th>
                                  <th scope="col">Pore Size <br/> (M)</th>
                                  <th scope="col">Weight <br/> (g/m2)</th>
                                  <th scope="col">Filteration Speed <br/> (sec*)</th>
                                  <th scope="col">Burst Strength <br/> (kg/cm2)</th>

                                </tr>
                              </thead>
                              <tbody>

                                <?php /*if(!empty($grade_data)) {
                                        foreach($grade_data as $data) {
                                        
                                          $grade_desc = '';
                                          if(isset($data->grade_desc) && !empty($data->grade_desc)){
                                            $grade_desc = $data->grade_desc;
                                          }

                                          $cnt = 0;
                                          if(isset($grade_code) && !empty($grade_code)) {
                                              $cnt = count($grade_code);
                                          }
                                          echo '<tr class="parent" id="row'.$data->id.'" title="Click to expand/collapse" style="cursor: pointer;">
                                                  <td>'.$data->grade_range.' <span style="float:right;">+</span></td>
                                                  <td>= No.'.$data->whatman_equivalent.'</td>
                                                  <td>'.$data->filtering_speed.'</td>
                                                  <td>'.$data->thickness.'</td>
                                                  <td>'.$data->pore_size.'</td>
                                                  <td>'.$data->weight.'</td>
                                                  <td>'.$data->filtration_speed.'</td>
                                                  <td>'.$data->burst_strength.'</td>
                                                </tr>';

                                            if(isset($grade_desc) && !empty($grade_desc)) {
                                              echo '<tr class="child-row'.$data->id.'" style="display:none;">
                                                  <th> </td>  
                                                  <th colspan="4">Grade 351 <span style="padding:15px; background: #A0BF1A; color:#fff;">Very Slow filtering</span></td>  
                                                  <th> </td>  
                                                  <th> Sizes <br/>(Diameter/mm) </td> 
                                                  <th> Product Code</td>  
                                                </tr>

                                                <tr class="child-row'.$data->id.'" style="display:none;">
                                                  <td> </td>  
                                                  <td colspan="4" rowspan='.$cnt.' style="text-align:left; vertical-align: top; width:50%;">'.$grade_desc.'
                                                  <td> &nbsp;</td>  
                                                  <td> </td>
                                                  <td> </td>
                                                </tr>';
                                                
                                                  if($data->id==$grade_code[0]->grade_desc_id) {
                                                    foreach($grade_code as $index => $gc) { 
                                                      echo '<tr class="child-row'.$data->id.'" style="display:none;">
                                                            <td> </td>
                                                            <td> </td>
                                                            <td>'.$gc->gc_size.'</td>
                                                            <td>'.$gc->gc_prod_code.'</td>
                                                            </tr>';   
                                                    } 
                                                  }
                                              }
                                            
                                        }
                                      } */?>
                                
                              </tbody>
                            </table>
                        </div>
                      </div>
                    </div>
                </section> -->

                <section class="site-section lighter-bg " id="other-product">
                    <div class="container">
                      <div class="row justify-content-center general-text-color">

                        <div class="col-md-12 general-text-color">
                          <h2 class="<?php echo $colorclass; ?>">Other Related Products</h2>
                        </div>

                      </div>
                    </div>
                </section>


              @include('frontend_view.layouts.contact_section')
                
            <!-- </div>
        </main> -->
    @endsection