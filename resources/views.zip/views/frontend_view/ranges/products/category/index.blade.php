@extends('frontend_view.layouts.layout')
    @section('content')
        
    <!-- <main class="main-content">
       <div class="container-fluid"> -->

<style>
  #table_presentation_data {
    table {
      thead {
        th:first-child{
          border-top-left-radius: 20px;
          padding-left: 40px;
        }
        th:last-child{
          border-top-right-radius: 20px;
        }
      }
      tbody {
        td:first-child{
          background-color: transparent;
          border-radius: 0;
          font-weight: normal;
          padding-left: 40px;
        }
        td:nth-child(2){
          border-left: 0px;
        }
      }
      margin-bottom: 50px;
    }
    .table-striped tbody tr:nth-of-type(even) {
        background-color: transparent;
    }
    .table-striped tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }
  }


.accordion-div{
  padding: 20px 0px;
}
.accordion {
  background-color: #df983f;
  color: #fff;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
  margin-bottom:5px;
}
.accordion:first-of-type{
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
}
/* .accordion:last-of-type{
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
} */

.active, .accordion:hover {
  background-color: #eb7f2d;
}

.panel {
  padding: 0 18px;
  display: none;
  background-color: white;
  overflow: hidden;
}

.arrow {
  border: solid #fff;
  border-width: 0 3px 3px 0;
  display: inline-block;
  padding: 3px;
  margin-right:10px;
}
.up {
  transform: rotate(-135deg);
  -webkit-transform: rotate(-135deg);
}

.down {
  transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
}


.hiddenRow {
    padding: 0;
}
tbody {
  border: 5px solid #fff;
}
.toggle_me{
  padding: 10px;
}

.hiddenRow:nth-of-type(1) div{
  margin-left: 30px;
}
.padding-10{
  padding: 10px;
}#table_presentation_data{
  border-bottom: 1px solid #d3d3d3;
}
  </style>
                
       @include('frontend_view.layouts.breadcrumb_nav')

            <?php 
            $cat_name = '';
            $colorclass = '';
              if(isset($cat_data[0]->cat_name) && !empty($cat_data[0]->cat_name) ) {
                $cat_name = $cat_data[0]->cat_name;
                $cat_range = $cat_data[0]->cat_ranges;
              }
              if(!empty($range_data) && $range_data[0]->range_id=='1'){
                $colorclass = 'rapid_text_color';
              }else{
                $colorclass = 'filtration_text_color';
              }
            ?>
               <section class="site-section-hero bg-image bg-header-image" data-stellar-background-ratio="0.5" id="section-home">
                  <div class="row justify-content-center align-items-center">
                      <div class="col-md-10">
                            <h1 class="heading bold-text <?php echo $colorclass; ?>" data-aos="fade-right"> <?php echo $cat_name; ?></h1>
                            <h3 class="text-white"><?php echo $cat_range; ?></h3>
                              
                              <!-- <p class='button-margin-15' data-aos="fade-up" data-aos-delay="300">
                                <a href="#section-contact" class="btn btn-primary btn-md smoothscroll">Read More</a>
                              </p> -->
                      </div>
                  </div>
                </section>


                <section class="site-section lighter-bg" id="table_presentation_data">
                    <div class="container">
                      <div class="row justify-content-center">
                        
                        <div class="col-md-12 general-text-color">
                          <h2 class="<?php echo $colorclass; ?>"><?php echo $cat_name.' '.$cat_range; ?></h2>
                          <p>Quantitative Filter Papers are used in applications where you want to find out how much of a certain substance is included in the specimen to be tested. Johnson Test Papers offers a series of extremely high purity, acid washed filter papers designed for a wide range of critical analytical procedures such agravimetric analysis. <a href=""> Read more </a></p>
                        </div>

                        <div class="col-md-12 text-center general-text-color">
                          <h2 class="heading">Categories</h2>
                        </div>


                        <?php if(!empty($range_data) && $range_data[0]->range_id=='1') { ?>
                          <div class="col-md-12 general-text-color">
                            <table class="table-striped">
                              <thead>
                                <tr class="gradient-left-to-right">
                                  <th scope="col">Product</th>
                                  <th scope="col">Graduation</th>
                                  <th scope="col">Presentation</th>
                                  <th scope="col">Product Code</th>
                                </tr>
                              </thead>
                              <tbody>
                                  <?php if(!empty($sub_cat_data) && $sub_cat_data!='') { 
                                          foreach ($sub_cat_data as $key => $value) { ?>
                                            <tr>
                                              <td>{{ $value->sub_cat_name.' '.$value->sc_ranges }}</td>
                                              <td>{{ $value->sp_graduation }}</td>
                                              <td>{{ $value->sp_presentation }}</td>
                                              <td>{{ $value->sp_prod_code }}</td>
                                            </tr>
                                  <?php } 
                                      } ?>
                                
                              </tbody>
                            </table>
                            
                            <div class="accordion-div">
                                <button class="accordion">Description</button>
                                <div class="panel">
                                  <p>{!! $cat_data[0]->cat_desc !!}</p>
                                </div>

                                <button class="accordion">Specification</button>
                                <div class="panel">
                                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                </div>

                                <button class="accordion">Downloads</button>
                                <div class="panel">
                                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                </div>

                                <button class="accordion">Documents</button>
                                <div class="panel">
                                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                </div>

                                <button class="accordion">Industries</button>
                                <div class="panel">
                                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                </div>
                            </div>

                          </div>
                        <?php 
                      
                      }else{ ?>

                        <div class="col-md-12">
                          <div class="card">
                            <div class="card-header">
                              
                              <div class="row">

                              <?php if ($range_data[0]->prod_id=='5' ) {  ?>

                                <div class="col-md-12 general-text-color">

                                          <table class="table-striped table-condensed" style="border-collapse:collapse;" id="extraction_table">
                                              <thead>
                                                  <tr class="gradient-left-to-right">
                                                      <th width="50%">Diameter</th>
                                                      <th width="25%">Presentation</th>
                                                      <th width="25%">Product Code</th>
                                                  </tr>
                                              </thead>


                                              <tbody>
                                              <tr data-toggle="collapse" data-target=".demo1" class="toggle_tr" style="background:orange;">
                                                  <td colspan="3"><span class="arrow down"></span>
                                                    <?php 
                                                        $er_dim = explode('x', $extraction_thimble[0]->er_dimension);
                                                        $er_dim = preg_replace('/[^A-Za-z0-9\-]/', '', $er_dim[0]);

                                                        $extaction_total = count($extraction_thimble)-1;

                                                        $ext_thim = explode('x', $extraction_thimble[$extaction_total]->er_dimension);
                                                        $ext_thim = preg_replace('/[^A-Za-z0-9\-]/', '', $ext_thim[0]);
                                                        
                                                        echo $er_dim.' - '.$ext_thim;
                                                    ?></td>
                                              </tr>

                                              <?php 
                                              $i=0;
                                              $teste = 0;
                                              foreach($extraction_thimble as $index => $data) { 

                                                $er_dim = explode('x', $data->er_dimension);
                                                $er_dim = preg_replace('/[^A-Za-z0-9\-]/', '', $er_dim);

                                                $ext_thim = explode('x', $extraction_thimble[$teste]->er_dimension);
                                                $ext_thim = preg_replace('/[^A-Za-z0-9\-]/', '', $ext_thim);

                                              ?>
                                              
                                                  <tr class="toggle_me">
                                                      <td class="hiddenRow">
                                                          <div class="collapse demo1"><?php echo $data->er_dimension; ?></div>
                                                      </td>
                                                      <td class="hiddenRow">
                                                          <div class="collapse demo1"><?php echo $data->er_presentation; ?></div>
                                                      </td>
                                                      <td class="hiddenRow">
                                                          <div class="collapse demo1"><?php echo $data->er_prod_code; ?></div>
                                                      </td>
                                                  </tr>
                                              <?php } ?>
                                              </tbody>
                                          </table>

                                </div>
                              </div>
                            
                                <div class="row text-center image-list">
                                  <?php } else{
                                  if(!empty($sub_cat_data) && $sub_cat_data!='') {
                                    $col = 'col-md-4';
                                    if(count($sub_cat_data)>3) {
                                      $col = 'col-md-3';
                                    }else if(count($sub_cat_data)==2) {
                                      $col = 'col-md-6';
                                    }else if(count($sub_cat_data)==1) {
                                      $col = 'col-md-12';
                                    }

                                    foreach ($sub_cat_data as $key => $value) {
                                      $url = url()->current().'/'.$value->subcat_url;

                                      echo '<div class="'.$col.' ranges_prod">
                                        <a href="'.$url.'">
                                          <img src="https://www.johnsontestpapers.com/images/products/filter-boxes.jpg" alt="Snow" class="img-fluid">
                                        </a>
                                        <div class="range_name">
                                          <label style="margin-top:20px;">'.$value->sub_cat_name.'<br/>'.$value->sc_ranges.'</label>
                                        </div>
                                      </div>';
                                    }
                                  }
                                  ?>

                                  
                              </div>

                              <?php if(count($sub_cat_data)>12) { ?>
                                <p class="text-center showing-result padding-top-bot-40"></p>
                                <a class="load-more"> Load More <span class="loading"><span></span></span></a>
                              <?php }  } ?>

                            </div>
                          </div>
                        </div>

                        <?php } ?>

                      </div>
                    </div>
                </section>


                <?php if($range_data[0]->prod_id!='5') { ?>
                <section class="site-section lighter-bg " id="other-product">
                    <div class="container">
                      <div class="row justify-content-center general-text-color">

                        <div class="col-md-12 general-text-color">
                          <h2 class="<?php echo $colorclass; ?>">Other Related Products</h2>
                        </div>

                      </div>
                    </div>
                </section>
                <?php } ?>
            
                <?php 
                if(!empty($range_data) && $range_data[0]->range_id=='2') { ?>
                <section class="site-section lighter-bg" id="section-nav">
                    <div class="container">
                      <div class="row justify-content-center general-text-color">

                        <div class="col-md-12">
                          <div class="card">

                              <div class="card-header">

                                <ul class="nav nav-tabs navmenu">
                                  <li class="col-md-4 text-center text-uppercase nav-item navbar-filter-papers active" data-myAttri="tab-1">
                                    <a  href="#tab-1" class="nav-link">Key Features</a>
                                  </li>
                                  <li class="col-md-4 text-center text-uppercase nav-item navbar-filter-papers" data-myAttri="tab-2">
                                    <a href="#tab-2" class="nav-link">Applications</a>
                                  </li>
                                  <li class="col-md-4 text-center text-uppercase nav-item navbar-filter-papers" data-myAttri="tab-3">
                                    <a href="#tab-3" class="nav-link">Industries</a>
                                  </li>
                                </ul>

                              </div>

                              <div class="card-body" id='tab-1-active'>
                                  <ul class="ul-check list-unstyled success">
                                    <li>Qualitative analysis.</li>
                                    <li>Low ash content 0.07% (Acid wash treated).</li>
                                    <li>High wet strength.</li>
                                    <li>Consistent performance Hardened grades available.</li>
                                    <li>Custom cut.</li>
                                    <li>Bulk packaging.</li>
                                    <li>Made of 100% cotton linters.</li>
                                    <li>Supplied in rolls, sheers, discs and folded filters.</li>
                                  </ul>
                              </div>

                              <div class="card-body" id='tab-2-active' style="display:none;">
                                  <ul class="ul-check list-unstyled success">
                                    <li>Qualitative analysis 2.</li>
                                    <li>Low ash content 0.07% (Acid wash treated).</li>
                                    <li>High wet strength.</li>
                                    <li>Consistent performance Hardened grades available.</li>
                                    <li>Custom cut.</li>
                                    <li>Bulk packaging.</li>
                                    <li>Made of 100% cotton linters.</li>
                                    <li>Supplied in rolls, sheers, discs and folded filters.</li>
                                  </ul>
                              </div>

                              <div class="card-body" id='tab-3-active' style="display:none;">
                                  <ul class="ul-check list-unstyled success">
                                    <li>Qualitative analysis 3.</li>
                                    <li>Low ash content 0.07% (Acid wash treated).</li>
                                    <li>High wet strength.</li>
                                    <li>Consistent performance Hardened grades available.</li>
                                    <li>Custom cut.</li>
                                    <li>Bulk packaging.</li>
                                    <li>Made of 100% cotton linters.</li>
                                    <li>Supplied in rolls, sheers, discs and folded filters.</li>
                                  </ul>
                              </div>

                          </div>
                        </div>
                        
                      </div>
                    </div>
                </section>
<?php } ?>


       @include('frontend_view.layouts.contact_section')
   

<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}


</script>
    @endsection