@extends('frontend_view.layouts.layout')
    @section('content')
        
    <!-- <main class="main-content">
       <div class="container-fluid"> -->

            @include('frontend_view.layouts.breadcrumb_nav')

                <section class="site-section-hero bg-image bg-header-image" data-stellar-background-ratio="0.5" id="main-banner">
                  <div class="row justify-content-center align-items-center">
                      <div class="col-md-10">
                            <?php if($range_data[0]->prod_id=='8') { ?>
                              <h1 class="heading filterpapercolor bold-text" data-aos="fade-right"> Find Your equivalent Filter</h1>
                              <h3 class="heading" data-aos="fade-right">Within our Johnson Test Papers Range</h3>
                            
                            <?php } else{ ?>
                              <h1 class="heading filterpapercolor bold-text" data-aos="fade-right"> <?php echo $range_data[0]->prod_name; ?></h1>
                              <h3 class="heading" data-aos="fade-right">We offers an extensive range of</h3>
                              <h3 class="themeTextColor heading" data-aos="fade-up">qualitative, ashless, and technical filter papers</h3>
                              <h3 class="heading" data-aos="fade-up">that cover broad applications <br/> in laboratory and industry</h3>
                                
                              <p class='button-margin-15' data-aos="fade-up" data-aos-delay="300">
                                <a href="#section-contact" class="btn btn-primary btn-md smoothscroll">Read More</a>
                              </p>
                            <?php } ?>
                      </div>
                  </div>
                </section>


                <section class="site-section lighter-bg" id="prod_content_section">
                    <div class="container">
                      <div class="row justify-content-center">
                        
                        <div class="col-md-12 general-text-color text-center">
                          <h4>Our Range of</h4>
                          <?php if($range_data->isNotEmpty()) {
                            echo '<h2>'. $range_data[0]->prod_name. '</h2>';
                          } 
                          if($prod_desc_data->isNotEmpty()) {
                            echo '<div class="content_description">'.$prod_desc_data[0]->pd_desc.'</div>';
                          } ?>
                        </div>


                        <div class="col-md-12">
                          <div class="card">
                            <div class="card-header">
                              <div class="row text-center image-list">
                                <?php 
                                  if(!empty($cat_data) && $cat_data!='') {
                                    $url = '';
                                    $col = 'col-md-4';
                                    if(count($cat_data)>3) {
                                      $col = 'col-md-3';
                                    }else if(count($cat_data)==2) {
                                      $col = 'col-md-6';
                                    }

                                    foreach($cat_data as $data) {
                                      $url = url()->current().'/'.$data->cat_url;
                                  ?>
                                    <div class="{{ $col }} ranges_prod">
                                      <a href="{{ $url }}">
                                        <img src="{{ url('assets/images/j-quant.png'); }}" alt="Snow" class="img-fluid tab_hover" style="height:300px;">
                                      </a>
                                        <div class="range_name">
                                          <label style="margin:20px 0 0;"><b>{{ $data->cat_name}}</b></label></br>
                                          <label><b>{{ $data->cat_ranges }}</b></label>
                                        </div>
                                    </div>
                                <?php  }
                                  }  ?>

                              </div>
                              <?php if(count($cat_data)>12) { ?>
                                <div class="content_count">
                                  <p class="text-center showing-result"></p>
                                  <a class="load-more"> Load More <span class="loading"><span></span></span></a>
                                </div>
                              <?php } ?>
                            </div>

                          </div>
                        </div>

                      </div>
                    </div>
                </section>


              <?php if($range_data[0]->range_id =='1') { ?>
                <section class="site-section lighter-bg" id="prod-section-nav">
                    <div class="container">
                      <div class="row justify-content-center general-text-color">

                        <div class="col-md-12">
                          <div class="card">

                              <div class="card-header">

                                <ul class="nav nav-tabs navmenu">
                                  <li class="col-md-4 text-center text-uppercase nav-item navbar-filter-papers active" data-myAttri="tab-1">
                                    <a  href="#tab-1" class="nav-link">Key Features</a>
                                  </li>
                                  <li class="col-md-4 text-center text-uppercase nav-item navbar-filter-papers" data-myAttri="tab-2">
                                    <a href="#tab-2" class="nav-link">Applications</a>
                                  </li>
                                  <li class="col-md-4 text-center text-uppercase nav-item navbar-filter-papers" data-myAttri="tab-3">
                                    <a href="#tab-3" class="nav-link">Industries</a>
                                  </li>
                                </ul>

                              </div>

                              <div class="card-body" id='tab-1-active'>
                                <?php if($prod_desc_data->isNotEmpty()) { 
                                  echo $prod_desc_data[0]->pd_features;
                                 } ?>
                              </div>

                              <div class="card-body" id='tab-2-active' style="display:none;">
                                <?php if($prod_desc_data->isNotEmpty()) { 
                                  echo $prod_desc_data[0]->pd_application;
                                 } ?>
                              </div>

                              <div class="card-body" id='tab-3-active' style="display:none;">
                                <?php if($prod_desc_data->isNotEmpty()) { 
                                  echo $prod_desc_data[0]->pd_industries;
                                } ?>
                              </div>

                          </div>
                        </div>

                        
                      </div>
                    </div>
                </section>
              <?php } 

              if($range_data[0]->range_id =='2') { ?>

                <section class="site-section lighter-bg" id="section-bio">
                    <div class="container">
                      <div class="row justify-content-center general-text-color">
                        
                        <div class="col-md-12">
                          <h3>General Information</h3>
                        </div>

                        <div class="col-md-12">
                          <div class="d-block d-md-flex mt-5">
                            
                            <div class="col-md-12" >
                              <div class="mr-md-auto mr-2">
                                <?php echo $range_data[0]->prod_desc; ?>

                                <p class="button-margin-15" >
                                  <a href="#section-contact" class="btn btn-primary btn-md smoothscroll">Read More</a>
                                </p>

                              </div>
                            </div>
                            

                          </div>
                            
                        </div>

                      </div>
                    </div>
                </section>
                <?php } ?>


               @include('frontend_view.layouts.contact_section')
                
            <!-- </div>
        </main> -->
    @endsection