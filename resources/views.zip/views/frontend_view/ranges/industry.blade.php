@extends('frontend_view.layouts.layout')
    @section('content')


    @include('frontend_view.layouts.breadcrumb_nav')

    <section class="site-section-hero bg-image" style="background-image: url(&quot;../../assets/images/img_9.jpg&quot;); height: 60vh; background-position: 50% 1%; min-height: 150px;" data-stellar-background-ratio="0.5" id="home-border"> 
        <div class="container">
            <div class="row justify-content-center  align-items-center" style="height: 60vh;">
                <div class="col-md-12 ">

                    <div class="row justify-content-center  align-items-center" style="height: 50vh;">
                        <div class="col-md-12">
                            <div data-aos="fade-up" data-aos-delay="100" class="aos-init text-white aos-animate">
                                <h1 class="">Supplying Your Testing Needs </h1>
                                <h1 class="themeTextColor">For All Industries </h1>
                                <p>Reliable, Percise & Innovative </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>


    <section class="site-section lighter-bg" id="industry_body">
        <div class="container">

            <div class="row justify-content-center">
            
                <div class="col-md-12 text-center">
                    <h1 class="themeTextColor">Industries</h3>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod<br/>
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam.</p>
                </div>

                <div class="col-md-12">

                        <div class="container">
                            <div class="row justify-content-center text-uppercase ">
                                
                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/lab.png') }}" style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 lab_col industry_content_css"> Laboratory</h4>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/healthcare.png') }}" style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 health_col industry_content_css"> Healthcare</h4>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/food.png') }}" style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 food_col industry_content_css"> Food & Beverages</h4>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/education.png') }}"  style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 edu_col industry_content_css"> <a href="{{ url('frontend/product/industry/education') }}">Education</a></h4>
                                    </div>
                                </div>


                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/environment.png') }}" style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 env_col industry_content_css"> Environmental</h4>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/cosmetic.png') }}" style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 cos_col industry_content_css"> Cosmetics</h4>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/industrial.png') }}" style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 ind_col industry_content_css"> Industrial</h4>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6">
                                    <div class="teaser hover_icon text-center">
                                    <div> 
                                        <img class="image-100" src="{{ url('assets/images/industry/water_treatment.png') }}"  style="height:170px; border-radius:50%;"> </div>
                                        <h4 class="topmargin_20 hover-color2 water_col industry_content_css"> Water Treatment</h4>
                                    </div>
                                </div>

                            </div>
                        </div>            
                </div>
            </div>

        </div>
    </section>

    @include('frontend_view.layouts.contact_section')
    @endsection