@extends('frontend_view.layouts.layout')
    @section('content')


    @include('frontend_view.layouts.breadcrumb_nav')

    <section class="site-section-hero bg-image" style="background-image: url(&quot;../../assets/images/vtk_banner.png&quot;); height: 60vh; background-position: 50% 1%; min-height: 150px;" data-stellar-background-ratio="0.5" id="home-border"> 
                <div class="row justify-content-center align-items-center" style="height:60vh;min-height:300px;">
                    <div class="col-md-7">
                          <h1 class="heading" data-aos="fade-right ">Visual Test Kits </h1>
                          <h1 class="heading text-uppercase" data-aos="fade-up">VTKolor</h1>
                    </div>
                </div>
    </section>


    <section class="site-section text-center site-section lighter-bg" id="oem_gradient_section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div data-aos="fade-up" data-aos-delay="100" class="aos-init aos-animate text-uppercase">
                        <h3 class="text-uppercase">Simple Colorimteric and Titrimetric test kits</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="site-section-hero bg-image" style="background-image: url(&quot;../../assets/images/visual_test_kit.png&quot;); height: 30vh; background-position: 50% 20.164px; min-height:250px;" data-stellar-background-ratio="0.5" id="test-strip-filteration"> 
        <div class="container" style="max-width:1440px;">
            <div class="row justify-content-center  align-items-center" style="min-height: 250px; height: 30vh;">
                <div class="col-md-8 text-center">
                    <div data-aos="fade-up" data-aos-delay="100" class="aos-init aos-animate text-uppercase">
                        <h3 class="text-uppercase">Available at Check2o.com</h3>
                        <h3 class="text-uppercase">pH Testing</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="site-section lighter-bg" id="contact_us">
        <div class="container">


            <div class="row justify-content-center">
            
                <div class="col-md-12 text-center">
                    <h1 class="themeTextColor">Our Range of</h1>
                    <h2 class="themeTextColor heading">Visual Test Kits</h2>
                </div>


            <div class="col-md-12 text-center">

                <div class="container">
                    <div class="row justify-content-center">

                <!-- <figure class="mb-12"> -->
                    <?php if(!empty($data) && !empty($data)) {
                        foreach($data as $value) {
                    ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="teaser hover_icon text-center">
                        <div> 
                            <img class="image-70" src="{{ url('assets/images/ammonia.png') }} " style="width:60%"> </div>
                            <h4 class="topmargin_20 hover-color2"> {{ $value->vtk_name }}</h4>
                            <p>{{ $value->vtk_desc }}</p> 
                        </div>
                    </div>

                    <?php } } ?>
                <!--</figure> -->
                    </div>
                </div>

            </div>            

        </div>
    </section>


    <section class="site-section-hero bg-image" style="background-image: url(&quot;../../assets/images/img_9.jpg&quot;); height: 30vh; background-position: 50% 20.164px; min-height:250px;" data-stellar-background-ratio="0.5" id="test-strip-filteration"> 
        <div class="container">
            <div class="row justify-content-center  align-items-center" style="min-height: 250px; height: 30vh;">
                
                <div class="col-md-12 ">
                

                    <div class="row justify-content-center  align-items-center" style="min-height: 250px; height: 30vh;">
                        <div class="col-md-8">
                            <div data-aos="fade-up" data-aos-delay="100" class="aos-init aos-animate text-white">
                                <h1>Explore the Pool & Spa Range</h1>
                                <h3>For All Your Testing Needs at <a href="https://draft.check2o.com/">draft.check2o.com/ </a></h3>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <img src="https://draft.check2o.com/wp-content/uploads/elementor/thumbs/Check2O_logo_small-qd9vmyzff0ftbzfher11m9c3ert3dhib9ktottpt6c.png" />
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    @include('frontend_view.layouts.contact_section')
    @endsection