<section class="site-section grey_background" id="contact_us_footer">
  <div class="container">
    <div class="row justify-content-center">
      
      <div class="col-md-12 text-center general-text-color">
          <?php 
          if(isset($range_data)) {
            
            if($range_data[0]->prod_id=='8') { ?>
            <h2 class="mb-5 heading themeTextColor">Did not find the right filter</h2>
            <h2>Let our expert Technical Team<br/>assist you with that </h2>
            
          <?php }  else { ?>
            <h2 class="mb-5 heading themeTextColor">Have an Enquiry ?</h2>
            <h2>Our expert customer support team are on hand to answer <br/>any of your queries </h2>
          <?php }  }else{ ?>

            <h2 class="mb-5 heading themeTextColor">Have an Enquiry ?</h2>
            <h2>Our expert customer support team are on hand to answer <br/>any of your queries </h2>
          <?php } ?>


      </div>
      
      <div class="col-md-12 text-center contactUs_enquiry_button">
        <a href="" class="btn btn-primary btn-md">Contact Us</a>
      </div>

    </div>
  </div>
</section>