@extends('frontend_view.layouts.layout')
    @section('content')

<style>
.centered {
  position: absolute;
  top: 30%;
  left: 25%;
  transform: translate(-50%, -50%);
}
</style>

    <!-- <section class="site-section-hero bg-image" style="background-image: url(&quot;../assets/images/contact_us.png&quot;); height: 60vh; background-position: 50% 1%; min-height: 150px;" data-stellar-background-ratio="0.5" id="home-border">  -->
    <section class="site-section zero_padding">
        <div class="row ">
            <div class="col-md-12">
                <img src="http://127.0.0.1:8000/assets/images/support/environmental_imprint.png" alt="Snow" style="width:100%; height:550px;"/>
                <h1 class="centered heading"><b><span class="text-white">Environmental </span><br/><span style="">Imprint </span></b></h1>
            </div>
        </div>
    </section>

    <section class="site-section lighter-bg" id="contact_us">
        <div class="container">

            <div class="row justify-content-center">
            
                <div class="col-md-12 text-center general-text-color aos-init aos-animate" data-aos="fade-right">
                    <h2 class="themeTextColor padding-top-bot-40"><b> We are commited to the environment, our packaging is made from 50% recycled materials and is widely recyclable. </b></h2>

                    <p class="padding-top-bot-40" style="width: 55%;margin: auto;">Best efforts are made to reduce our carbon footprint, such as unplugging devices and ensuring machinery is only operated when needed.</p>
                    <p style="width: 55%;margin: auto;">Our production is also considered, so any waste material during the production process are either reassembled or recycled.</p>
                </div>
                


            </div> <!-- row close-->
        </div> <!-- Container close -->
    </section>

    @include('frontend_view.layouts.contact_section')
    @endsection