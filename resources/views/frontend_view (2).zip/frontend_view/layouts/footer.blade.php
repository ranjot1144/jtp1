                <div class="row justify-content-center">
                  <div class="col-md-12 text-center">
                    <label class="text-white margin-15"> &copy;
                      <script>document.write(new Date().getFullYear());</script> 
                      Compare Policy
                    </label>
                  </div>
                </div>